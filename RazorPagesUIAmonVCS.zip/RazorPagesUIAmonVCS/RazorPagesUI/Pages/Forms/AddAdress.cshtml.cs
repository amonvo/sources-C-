using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorPagesUI.Pages.Forms
{
    public class AddAdressModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
